/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.1 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Shell\Main.c; Contains the (unnamed)shell<<<<*/
/*>>>>Shell Extension Version 0.0.1<<<<*/
#ifndef SHELL
#define SHELL
#define SHELL_VERSION 0.0.1

#endif
byte write_disk(drive_params,byte[512]);
void reset_disks(byte);
unsigned char read_disk(drive_params);
void Shelp(void);
void Load_lowbasic(void);
void Scheck_scroll(void);
void testing(void);
signed int SMain(char* Arguments)  /*The big shell main; Arguments is currently not used and is there for future use; can return an error value*/
{
	char tmp[32];
	byte didit=0;
	unsigned char* command[scanf_BUFFER];
	tmp[0]=0;
	tmp[1]=0;
	init(tmp);
	tmp[0]=1;
	while (tmp[0]=1) {
		nl();
		printf("->:");
		*command=scanf();
		nl();
		if (streq(*command,"help")==1) { /*THANK YOU FOR THE PERSON WHO CREATED OPOS AND LET ME USE THE WONDERFUL FUNCTION OF streq*/
			Shelp(); didit=1;
		}
		if (streq(*command,"reboot")==1){ reboot(); didit=1;}
		if (streq(*command,"basic")==1){ Load_lowbasic(); didit=1;}
		if (streq(*command,"test")==1){testing(); didit=1;}
		

Scheck_scroll();

if (didit==0) {
	printf("Command not recognized!");
}

didit=0;
}
}

signed int init(char args[32]) /*shell initalization args is currently unused*/
{
	setvideomode(0x02);
	if (args[0]==1){
		setvideomode(0x02);}
		if (args[0]>1) { return -1;}
	setvideopage(args[1]);
	cls();
}

void Shelp(void) /*displays help message*/
{
			printf("basic -Starts the basic interpreter(not currently supported)");
			nl();
			printf("help -Displays this text");
			nl();
			printf("reboot -Reboots the PC");
			nl();
			printf("load -loads a sector from the currently floppy"); nl(); printf("disk to memory and  jumps to it");
}

void Load_lowbasic(void) /*probably wont be here for long*/
{
	printf("Currently under development."); nl(); printf("Remeber this is an alpha!");
}

void Scheck_scroll(void) /*checks the scrolling and if it is down to where u cant see the cursor it will cls*/
{
	if (getcury()>20) {
		printf("ok??");
		cls();
	}
}

void testing(void) /*just a reserved function for testing junk*/
{
	byte *tmp[512];
drive_params t;
	asm int 83
	tmp[0]='1';
	t.cylinder=0;
	t.head=0;
	t.sector=1;
	t.drive=0x00;
	/*reset_disks(0x00);*/
	*tmp=write_disk(t,tmp);
	if (*tmp[0]==0xeb) {
		printf("yay");
	}
	asm mov t.error,ah
		if (t.error==0xf4){printf("grrr");}

/*asm mov WORD [es:20*4+2], CS omg that actually works*/
}


		