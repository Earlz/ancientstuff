/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.1 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>LowLevel.c; Low level C functions consiting mostly of inline asm, This is the true core<<<<*/
void putcur(word,word);
void printf(char*);
void testi(void);
void setvideomode(u8b mode) /*sets the video mode using int 10h*/
{
	asm mov ah,0x00
	asm mov al,mode
	asm int 0x10
}

byte getvideomode(void)
{
	byte ret;
	byte tmp;
	asm mov ah,0x0f
		asm int 0x10
		asm mov tmp,al
		ret=tmp;
		return ret;
}


void setvideopage(u8b page) /*sets the video page and updates the video_page variable*/
{
	asm mov al,page
	asm int 0x10
	video_page=page;
}
void reboot(void) /*warm reboots the pc*/
{
	asm int 0x19
}
/*
u16b memorysize(void)
{
	u16b a;
	u16b *ret;
	asm int 0x12
	asm mov a,ax 
	*ret=a;
	return *ret;
}
not working
*/
void bprint(u8b* chr) /*prints a single character to the screen*/
{
	asm mov ah,0x0e
	asm mov al,chr
	asm int 0x10
}


void read_disk2(u8b numsec,u8b track,u8b sector,u8b head,u8b drive, u8b high,u8b low) /*reads a single sector from the chosen disk; high and low is address to buffer*/
{
	asm mov ah,0x02
	asm mov al,numsec
	asm mov ch,track
	asm mov cl,sector
	asm mov dh,head
	asm mov dl,drive
	asm mov es,high
	asm mov bx,low
	asm int 0x13
}

void write_disk2(u8b numsec,u8b track,u8b sector,u8b head,u8b drive, u8b high,u8b low) /*rwrites a single sector from the chosen disk; high and low is address to buffer*/
{

	asm mov ah,0x03
	asm mov al,numsec
	asm mov ch,track
	asm mov cl,sector
	asm mov dh,head
	asm mov dl,drive
	asm mov es,high
	asm mov bx,low
	asm int 0x13
}

void putdot(u8b color,u8b col,u8b row)  /*puts a single dot on the screen; col is x, row is y, only works in graphics mode*/
{
	asm mov ah,0x0c
	asm mov al,color
	asm mov bh,video_page
	asm mov cx,col
	asm mov dx,row
	asm int 0x10
}


void writestring(u8b *mode,u8b *attrib,u8b *row,u8b *col,u8b *len,u8b *high,u8b *low) /*writes a string to the screen>UNTESTED<*/
{
	asm mov ah,0x03
	asm mov al,mode
	asm  mov bl,attrib
	asm mov bh,video_page
	asm mov dh,row
	asm mov dl,col
	asm mov cx,len
	asm mov es,high
	asm mov bp,low
	asm int 0x10
}

void putcur(word x,word y) /*repositions the cursor*/
{
	asm mov ah,0x02
	asm mov dh,y
	asm mov dl,x
	asm mov bh,video_page
	asm int 0x10
}
u8b getkey1(void) /*current to-be-replaced getkey function*/
{
	u8b rety;
	u8b tmpa,tmpb;
	asm mov ah,0x00
	asm int 0x16
	/*asm mov scanc,ah*/
	asm mov rety,al
	/*
	*key=tmpb;
	*scanc=tmpa;
*/
return rety;
}
byte getcurx() /*gets the current cursor X position*/
{
	u8b ret;
	u8b tmp;
	asm mov ah,0x03
	asm mov bh,video_page
	asm int 0x10
	asm mov tmp,dl
	ret=tmp;
	return ret;
}
byte getcury() /*gets the current cursor Y position*/
{
	u8b ret;
	u8b tmp;
	asm mov ah,0x03
	asm mov bh,video_page
	asm int 0x10
	asm mov tmp,dh
	ret=tmp;
	return ret;
}

 void _scrollup(int nol,int x1,int y1,int x2,int y2) /*scrolls the screen up*/
 {	asm	mov ah , 0x06
	asm	mov al , nol
	asm	mov cl , x1
	asm	mov ch , y1
	asm	mov dl , x2
	asm	mov dh , y2
	asm	mov bh , 0
	asm	int 0x10
 }


void int_init()
{
	word tmp;
asm xor ax,ax	
asm mov es,ax	
	tmp=testi;
		asm mov bx,tmp
	asm mov WORD [es:83*4], bx
asm mov WORD [es:83*4+2], CS
}

void testi(void)
{
	printf("hey whats up");
	asm iret
}





/*
char* test_get()  /* asm code borrowed from an example from enu8086
{
	char* ret[80]
	
asm mov 



	PUSH    AX
PUSH    CX
PUSH    DI
PUSH    DX

MOV     CX, 0                   ; char counter.

CMP     DX, 1                   ; buffer too small?
JBE     empty_buffer            ;

DEC     DX                      ; reserve space for last zero.


;============================
; Eternal loop to get
; and processes key presses:

wait_for_key:

MOV     AH, 0                   ; get pressed key.
INT     16h

CMP     AL, 13                  ; 'RETURN' pressed?
JZ      exit


CMP     AL, 8                   ; 'BACKSPACE' pressed?
JNE     add_to_buffer
JCXZ    wait_for_key            ; nothing to remove!
DEC     CX
DEC     DI
PUTC    8                       ; backspace.
PUTC    ' '                     ; clear position.
PUTC    8                       ; backspace again.
JMP     wait_for_key

add_to_buffer:

        CMP     CX, DX          ; buffer is full?
        JAE     wait_for_key    ; if so wait for 'BACKSPACE' or 'RETURN'...

        MOV     [DI], AL
        INC     DI
        INC     CX
        
        ; print the key:
        MOV     AH, 0Eh
        INT     10h

JMP     wait_for_key
;============================

exit:

; terminate by null:
MOV     [DI], 0

empty_buffer:

POP     DX
POP     DI
POP     CX
POP     AX

}

*/


