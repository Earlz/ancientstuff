/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.1 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>raw_RW.h; Contains low level disk functions also includes vital cluster operations<<<<*/
/*>>>>FDFS Version 0.0.1*/
/*may contain simplified interrupts*/

void reset_disks(byte drive)
{
	asm mov ah,0x00
		asm mov dl,drive
		asm int 0x13
}

/*
void read_disk(word pdrive) /*send it the address*
{
word *cylinder;
word *sector;
	word sectora,cylindera;
	byte *head;
	byte *drive;
	byte heada,drivea;
cylinder=pdrive+2; /*generates error..wtf without the * *
sector=pdrive+3;
head=pdrive+4;
drive=pdrive+5;
sectora=*sector;
cylindera=*sector;
heada=*head;
drivea=*drive;
if (cylinder==1) {
		printf("yay!");
}

}
*/

unsigned char read_disk(drive_params t) /*reads a single sector and returns it */
{
	byte *ret[512];
	byte s[512];
	word temp;
	byte tmp;
	tmp=0x02;
		asm mov ah,tmp
		asm mov s[0],ah
		if (s[0]==0xf4) {
		printf("wtf!");
	}
		asm mov al,1
		asm mov ch,t.cylinder
		asm mov cl,t.sector
		asm mov dh,t.head
		asm mov dl,t.drive
		asm mov temp,cs
		if (temp==0xF4){
		printf("ah ha");}
		asm mov es,temp
		temp=&ret;
		asm mov bx,temp
		asm int 0x13
asm mov temp,ah
		if (temp>0x00) {
		printf(temp);
printf("uh oh");
		/**ret=temp;*/
		}
		return *ret;

}

byte write_disk(drive_params t,byte buffer[512]) /*reads a single sector and returns it */
{
	byte ret;
	word temp;
	byte tmp;
asm mov ah,0x02
		asm mov al,1
		asm mov ch,t.cylinder
		asm mov cl,t.sector
		asm mov dh,t.head
		asm mov dl,t.drive
		asm mov temp,cs
		asm mov es,temp
		temp=&ret;
		asm mov bx,temp
		asm int 0x13
asm mov tmp,ah
		ret=tmp;
		
		return ret;

}














	