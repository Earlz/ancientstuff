This is a pre-release version of JuleOS 0.1.0 
this is only being done to distribute the source code so far!

notice that there ARE code inconsistencies between 0.0.4 and 0.1.0 so do not use 0.0.4 infact it may soon be deleted from the list of releases

must have turboc installed and the directory under %path%