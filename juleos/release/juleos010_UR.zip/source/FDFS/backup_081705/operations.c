

byte newfile(char*fil