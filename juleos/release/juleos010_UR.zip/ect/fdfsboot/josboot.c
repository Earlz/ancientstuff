


/*condensed source code*/


void main(void)
{
	
}
	