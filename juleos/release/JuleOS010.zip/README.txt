notice that there ARE code inconsistencies between 0.0.4 and 0.1.0 so do not use 0.0.4 infact it may soon be deleted from the list of releases

must have turboc installed and the directory under %path% must have tasm installed and under
%path% or tasm.exe under the same directory as turboc


for draw the paint program these are the controls
arrowkeys; cursor movment
n;lift pen/erase
r;chage color to red
g;change color to gree
b;change color to blue
e;exit
c;cls
w;change color to white
l;load a saved image- not working
s;save an image- not working