/*installer kernel*/
/*not needed yet so is halted*/