/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Main.c; Initializations, defines, includes, and calls the shell<<<<*/
          char *strptr[20];
#include "prepu.c"

int main()
{

signed int ret;


	ret=SMain(0); /*call the shell main*/
/*add error checking for ret here*/

}
/*note: there are 9 full segments to use and probably last  2 will be reserved for caching and big vars, first 1 will be for juleos kernel, and the rest applications can fight over  plus there is a .98th of a segment at the end but not sure why it isnt a full segment*/
/*note: the current fdfs design has a limit of 4064 names including special entries*/
/*
Example on how to read a value from an address in a different offset(segment)
this reads how many coloums are on the screen
asm mov ax,0x0040
asm mov ah,0x0084
asm mov tmp,ax:ah
if (tmp==0x13) {
printf ("Yay!");
}
printf(tmp);
*/

	