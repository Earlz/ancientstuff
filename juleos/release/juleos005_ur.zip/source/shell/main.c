/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Shell\Main.c; Contains the (unnamed)shell<<<<*/
/*>>>>Shell Extension Version 0.1.0<<<<*/

/*making arrays of pointers is useless, change it*/

#ifndef SHELL
#define SHELL
#define SHELL_VERSION 0.0.3
#define SHELL_VERSIONs "0.0.3"
unsigned char* command[scanf_BUFFER];
#include "shell\interf.c"
#include "shell\notes.c"
#endif
void Shelp(void);
void Load_lowbasic(void);
void Scheck_scroll(void);
void testing(void);
void shtime(void);
void test2(void);
void ver(void);
void notes(void);

byte docmd(void)
{/*something great to do would be to assign this to a memory area and then have it behave like an interrupt*/
	byte didit=0;
	if (streq(*command,"help")==1) {Shelp(); didit=1;}
	if (streq(*command,"ver")==1){ver();didit=1;}
	if (streq(*command,"cls")==1){cls();didit=1;}
	if (streq(*command,"reboot")==1){ reboot(); didit=1;}
	if (streq(*command,"basic")==1){ Load_lowbasic(); didit=1;}
	if (streq(*command,"test")==1){testing(); didit=1;}
	if (streq(*command,"time")==1){shtime(); didit=1;}
	if (streq(*command,"test2")==1){test2(); didit=1;}
	if (streq(*command,"format")==1){sformat(); didit=1;}
	if (streq(*command,"notes")==1){notes();didit=1;}
	if (didit==0) {
		printf("Command not recognized!");
	}

	didit=0;
}

signed int SMain(char* Arguments)  /*The big shell main; Arguments is currently not used and is there for future use; can return an error value*/
{
	char tmp[32];
	byte didit=0;
	tmp[0]=0;
	tmp[1]=0;
	init(tmp);
	tmp[0]=1;
	printf("JuleOS version 0.0.4 pre-alpha");
	while (tmp[0]=1) {
		nl();
		printf("->:");
		*command=scanf();
		nl();
		docmd();

Scheck_scroll();


}
}

signed int init(char args[32]) /*shell initalization args is currently unused*/
{
	setvideomode(0x02);
	if (args[0]==1){
		setvideomode(0x02);}
		if (args[0]>1) { return -1;}
	setvideopage(args[1]);
	setvideomode(0x03);
}

void Shelp(void) /*displays help message*/
{
			printf("basic -Starts the basic interpreter -not included in this version");
			nl();
			printf("help -Displays this text");
			nl();
			printf("reboot -Reboots the PC -beta");
			nl();
			printf("cls -clears the screen");
			nw
			printf("format -formats a floppy disk using FDFS -beta");
			nw
			printf("time -displays current time -alpha");
			nw
			printf("ver -displays version information");
			nw
			printf("test -a reserved testing command to prevent clutter -use at own risk");
			nw
			printf("test2 -another test function so you can work on 2 things at one time");
			
			
			
}

void Load_lowbasic(void) /*probably wont be here for long*/
{
	printf("Currently under development."); nl(); printf("Remeber this is an alpha!");
}

void Scheck_scroll(void) /*checks the scrolling and if it is down to where u cant see the cursor it will cls*/
{
	if (getcury()>20) {
		cls();
	}
}
void test4(int sig){
	
}
void testing(void) /*just a reserved function for testing junk*/
{
	void *t,*func;
	func=&test4;
signal(1, func); 

}

void shtime(void)
{
long ticks;
long tmp,tmp2;
byte buffer[20];byte *minutess,*hourss;
int hours;
int minutes;
asm hi:
ticks=biostime(0,0);
tmp=ticks/18;
hours=tmp/60; /*get hours*/
minutes=tmp%60;
minutess= itoa(minutes,*buffer,10); /*problem with this, not the time*/
hourss=itoa(hours,*buffer,10);
printf(hourss);nw
printf(minutess);nw

}
byte isset(word val,byte bit) /*fucked up turboc odnt liek for something useful to be in a function*/
{
	          char buffer[20];
          char *str;

buffer[19]=itoa(125,&buffer,10);
if (buffer[0]=='1') {printf("yay");}
printf(buffer);

}
void test2(void)
{char it[255];
char *pit;
pit=&it;printf("hello: ");
input(&it);
	printf(it);

}

void printequip(void)
{
	char buffer[20];
	char tmp[20];
	word equip;
	equip=biosequip();		
	buffer[19]=itoa(equip,&buffer,2);
	
}
/*first byte is characters, second is attribs*/




void num2asci(word number)
{
}

void ver(void)
{
	printf("Shell version: ");printf(SHELL_VERSIONs); nw
	printf("JuleOS version: ");printf(JULEOS_VERs);
}






/*

number to ascii numeric character converter

; ax = unsigned integer
; ax, at most, is a 5-digit number
mov si, outStr+4 ; point si at the right-most char of outStr
mov cx, 10 ; the base
xor dx, dx ; zero out dx as dx:ax will be divided by cx
LP:
div cx
; ax = Quotient ; dx = Remainder < cx(=10), so only dl matters
add dl, 30h ; convert a binary value to its ASCII numeric digit
mov [si], dl ; store this ASCII numeric digit to outStr
dec si ; point si to the next char (to the left)
xor dx, dx ; zero out dx (to prepare dx:ax for the next div)
or ax, ax ; check if ax is already zero
jnz LP ; if not, next loop; if yes, quit
inc si ; cancel out the effect of the last "dec si"
; so that si now points at the first (the left-most) char
; of the number to be printed
int 21h
...
outStr db '01234', 0 ; output string for a 5-digit numbe*/

	


/*
library of successful function tests
void test2(void)
{
            #include <stdlib.h>

            int bas2 = 2;
            int bas8 = 8;
            int bas16 = 16;
            char *string = "5";
            long longint;
            char *termn;
                longint = strtol(string,&termn,10);
				if (longint==5){printf("yay");} /*i bet i could use this function for bios equip checks

}

void test2(void)
{
 byte a; 
 pokeb(0xfa,0x01,24);
     a=peekb(0xfa,0x01);
     if (a==24) {printf("w00t");}  /*i spy... something useful ,vga: A000 segment

}




unworking

 byte a; 
 dword offset;
 setvideomode(0x12);
 offset = 640 * 5 + 5;
 pokeb(0xA000 ,offset,0xff);
*/
	