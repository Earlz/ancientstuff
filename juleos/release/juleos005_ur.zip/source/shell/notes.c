void nhelp(void);
void nwrite(void);
void nread(void);
void notes(void){
	byte *buffer[16];
	byte didit;
	cacheindex(0);
	printf("welcome to Notes beta");nw
	printf("This is quite unstable but demonstrates index's and is more of a diagnostic utility");nw
		printf("type help for list");nw
	for (;;){

	*buffer=scanf();
	nw
	if (streq(*buffer,"help")==1){nhelp(); didit=1;}
	if (streq(*buffer,"read")==1){nread(); didit=1;}
	if (streq(*buffer,"write")==1){nwrite(); didit=1;}
	if (streq(*buffer,"exit")==1){return 0; didit=1;}
	nw
	
}	
}



void nhelp(void){
	printf("read -reads an index entry");nw
	printf("write -writes an index entry");nw
	printf("help -displays this");nw
	printf("new -creates a new index, not working");nw
	printf("exit -exits Notes"); nw
}

void nread(void)
{
	byte buffer[16];
	byte *cmd[16];
	byte *ptr;
	printf("entry number: ");
	*cmd=scanf();nw
	*buffer=get_entry(2,&buffer);
	printf(buffer);

}
void nwrite(void){
		byte buffer[16];
	byte *cmd[16];
	byte *ptr;
	printf("entry number: ");
	*cmd=scanf();nw
	/**ptr=strtol(*cmd,buffer,10);*/
	*cmd=scanf();
	printf(".");
	write_entry(2,&cmd);
}


