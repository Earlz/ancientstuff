int test(int a)
{
	a++;
	return a;
}

void main(void)
{
	test(2);
}


