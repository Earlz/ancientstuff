/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>MidLevel.c; Includes higher level functions using none or very little inline asm, This has a high dependency on LowLevel.c<<<<*/
void printf(char*);
 u16b strlen(u8b *s1) /*gets the length of a string; copied from opos*/
 {	u16b counter =0;
	while(*s1)
	{	counter++;
		s1++;
	}
	return counter;
 }

 u8b streq(char *s1,char *s2) /*returns 1 if the strings are alike, copied from opos*/
 {	if(strlen(s1)==strlen(s2))
	{	int i=0;
		for(;i<strlen(s1);++i)
		{	if(s1[i]!=s2[i])
				return 0;
		}
		return 1;

	}
	return 0;
}

void line(u8b x1,u8b y1,u8b x2,u8b y2,u8b color) /*draws a line to the screen, currently wip*/
{
	u8b tmp;
	u8b tmpx,tmpy;
	
tmpx=x1;
tmpy=y1;
tmp=1;
	if (x1<x2) {
		if (y1<y2) {
			while (tmp) {
				putdot(color,tmpx,tmpy);
				if (tmpx<x2){
				tmpx++;
			}
			if (tmpy<y2)  {
				tmpy++;
			}
			if (tmpy=y2,tmpx=x2) {
			tmp=0;
		}
		}
	}
}
}	
			





void box(u8b l,u8b w,u8b x,u8b y,u8b color) /*draws a box to the screen, currently wip*/
{
	u8b tmpx,tmpy,i,t;
	
	tmpx=x;
	tmpy=y;
	t=1;
	while (t=1) {
		for (i=1;i==w;i+1) {
			putdot(color,tmpx+i,tmpy);
		}
		if (tmpy==y+l){
			t=0;
		}
		++tmpy;
	}
}

void DrawBox(u8b left, u8b top,u8b right,u8b bottom,u8b color) /*draws a box but not sure where it came from...*/
{
  u8b tmpx,tmpy;
  for(tmpx= left; tmpx > (right - left); tmpx++)
  {
    for(tmpy = top;tmpy > (bottom - top); tmpy++)
    {
      putdot(color,tmpx, tmpy);
    }
  }
}
	
void nl() /*positions cursor with a new line*/
{
	putcur(0,getcury()+1);
}	

void cls(void) /*clears the screen by resetting the video mode*/
{
	setvideomode(0x03);
}

 void cls2 (void)
 {	/* use the scroll function to clear the screen */
	_scrollup(0,0,0,79,24);
 }


/*provided by raven*/

#ifndef VIDEO_H
#define VIDEO_H

	void plotpixel(dword x, dword y, dword color)
	{
	dword offset;
	*VideoMemory=0xa000;
		offset = 640 * y + x;
		VideoMemory[offset] = color;
	}


#endif


