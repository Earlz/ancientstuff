/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>raw_RW.h; Contains low level disk functions also includes vital cluster operations<<<<*/
/*>>>>FDFS Version 0.0.1*/
/*may contain simplified interrupts*/

void reset_disks(byte drive)
{
	asm mov ah,0x00
		asm mov dl,drive
		asm int 0x13
}

/*
void read_disk(word pdrive) /*send it the address*
{
word *cylinder;
word *sector;
	word sectora,cylindera;
	byte *head;
	byte *drive;
	byte heada,drivea;
cylinder=pdrive+2; /*generates error..wtf without the * *
sector=pdrive+3;
head=pdrive+4;
drive=pdrive+5;
sectora=*sector;
cylindera=*sector;
heada=*head;
drivea=*drive;
if (cylinder==1) {
		printf("yay!");
}

}
*/

unsigned char read_disk(drive_params t) /*reads a single sector and returns it */
{

	byte ret[512];
	byte temp;
	word tmp2;
	dword tmp3;
	byte tmp;
		asm mov tmp3,cs
		asm mov es,tmp3
		tmp2=&ret;
		asm mov bx,tmp2
		asm mov ah,0x02
		asm mov al,1
		asm mov ch,t.cylinder
		asm mov cl,t.sector
		asm mov dh,t.head
		asm mov dl,t.drive
		asm mov ah,0x02
		asm int 0x13
asm mov temp,ah
		if (temp>0x00) {
		ret[0]=temp;
		if (temp==0){printf("0");}
if (temp==1){printf("1");}
if (temp==2){printf("2");}
if (temp==3){printf("3");}
if (temp==4){printf("4");}
if (temp==5){printf("5");}
if (temp==6){printf("6");}
if (temp==7){printf("7");}
if (temp==8){printf("8");}
if (temp==9){printf("9");}
if (temp==10){printf("10");}
if (temp==11){printf("11");}
if (temp==12){printf("12");}
if (temp==13){printf("13");}
if (temp==14){printf("14");}
if (temp==15){printf("15");}
if (temp==16){printf("16");}
if (temp==17){printf("17");}
if (temp==18){printf("18");}
if (temp==19){printf("19");}
if (temp==20){printf("20");}
if (temp==21){printf("21");}
if (temp==22){printf("22");}
if (temp==23){printf("23");}
if (temp==24){printf("24");}
if (temp==25){printf("25");}
if (temp==26){printf("26");}
if (temp==27){printf("27");}
if (temp==28){printf("28");}
if (temp==29){printf("29");}
if (temp==30){printf("30");}
if (temp==31){printf("31");}
if (temp==32){printf("32");}
if (temp==33){printf("33");}
if (temp==34){printf("34");}
if (temp==35){printf("35");}
if (temp==36){printf("36");}
if (temp==37){printf("37");}
if (temp==38){printf("38");}
if (temp==39){printf("39");}
if (temp==40){printf("40");}
if (temp==41){printf("41");}
if (temp==42){printf("42");}
if (temp==43){printf("43");}
if (temp==44){printf("44");}
if (temp==45){printf("45");}
if (temp==46){printf("46");}
if (temp==47){printf("47");}
if (temp==48){printf("48");}
if (temp==49){printf("49");}
if (temp==50){printf("50");}
if (temp==51){printf("51");}
if (temp==52){printf("52");}
if (temp==53){printf("53");}
if (temp==54){printf("54");}
if (temp==55){printf("55");}
if (temp==56){printf("56");}
if (temp==57){printf("57");}
if (temp==58){printf("58");}
if (temp==59){printf("59");}
if (temp==60){printf("60");}
if (temp==61){printf("61");}
if (temp==62){printf("62");}
if (temp==63){printf("63");}
if (temp==64){printf("64");}
if (temp==65){printf("65");}
if (temp==66){printf("66");}
if (temp==67){printf("67");}
if (temp==68){printf("68");}
if (temp==69){printf("69");}
if (temp==70){printf("70");}
if (temp==71){printf("71");}
if (temp==72){printf("72");}
if (temp==73){printf("73");}
if (temp==74){printf("74");}
if (temp==75){printf("75");}
if (temp==76){printf("76");}
if (temp==77){printf("77");}
if (temp==78){printf("78");}
if (temp==79){printf("79");}
if (temp==80){printf("80");}
if (temp==81){printf("81");}
if (temp==82){printf("82");}
if (temp==83){printf("83");}
if (temp==84){printf("84");}
if (temp==85){printf("85");}
if (temp==86){printf("86");}
if (temp==87){printf("87");}
if (temp==88){printf("88");}
if (temp==89){printf("89");}
if (temp==90){printf("90");}
if (temp==91){printf("91");}
if (temp==92){printf("92");}
if (temp==93){printf("93");}
if (temp==94){printf("94");}
if (temp==95){printf("95");}
if (temp==96){printf("96");}
if (temp==97){printf("97");}
if (temp==98){printf("98");}
if (temp==99){printf("99");}
if (temp==100){printf("100");}
if (temp==101){printf("101");}
if (temp==102){printf("102");}
if (temp==103){printf("103");}
if (temp==104){printf("104");}
if (temp==105){printf("105");}
if (temp==106){printf("106");}
if (temp==107){printf("107");}
if (temp==108){printf("108");}
if (temp==109){printf("109");}
if (temp==110){printf("110");}
if (temp==111){printf("111");}
if (temp==112){printf("112");}
if (temp==113){printf("113");}
if (temp==114){printf("114");}
if (temp==115){printf("115");}
if (temp==116){printf("116");}
if (temp==117){printf("117");}
if (temp==118){printf("118");}
if (temp==119){printf("119");}
if (temp==120){printf("120");}
if (temp==121){printf("121");}
if (temp==122){printf("122");}
if (temp==123){printf("123");}
if (temp==124){printf("124");}
if (temp==125){printf("125");}
if (temp==126){printf("126");}
if (temp==127){printf("127");}
if (temp==128){printf("128");}
if (temp==129){printf("129");}
if (temp==130){printf("130");}
if (temp==131){printf("131");}
if (temp==132){printf("132");}
if (temp==133){printf("133");}
if (temp==134){printf("134");}
if (temp==135){printf("135");}
if (temp==136){printf("136");}
if (temp==137){printf("137");}
if (temp==138){printf("138");}
if (temp==139){printf("139");}
if (temp==140){printf("140");}
if (temp==141){printf("141");}
if (temp==142){printf("142");}
if (temp==143){printf("143");}
if (temp==144){printf("144");}
if (temp==145){printf("145");}
if (temp==146){printf("146");}
if (temp==147){printf("147");}
if (temp==148){printf("148");}
if (temp==149){printf("149");}
if (temp==150){printf("150");}
if (temp==151){printf("151");}
if (temp==152){printf("152");}
if (temp==153){printf("153");}
if (temp==154){printf("154");}
if (temp==155){printf("155");}
if (temp==156){printf("156");}
if (temp==157){printf("157");}
if (temp==158){printf("158");}
if (temp==159){printf("159");}
if (temp==160){printf("160");}
if (temp==161){printf("161");}
if (temp==162){printf("162");}
if (temp==163){printf("163");}
if (temp==164){printf("164");}
if (temp==165){printf("165");}
if (temp==166){printf("166");}
if (temp==167){printf("167");}
if (temp==168){printf("168");}
if (temp==169){printf("169");}
if (temp==170){printf("170");}
if (temp==171){printf("171");}
if (temp==172){printf("172");}
if (temp==173){printf("173");}
if (temp==174){printf("174");}
if (temp==175){printf("175");}
if (temp==176){printf("176");}
if (temp==177){printf("177");}
if (temp==178){printf("178");}
if (temp==179){printf("179");}
if (temp==180){printf("180");}
if (temp==181){printf("181");}
if (temp==182){printf("182");}
if (temp==183){printf("183");}
if (temp==184){printf("184");}
if (temp==185){printf("185");}
if (temp==186){printf("186");}
if (temp==187){printf("187");}
if (temp==188){printf("188");}
if (temp==189){printf("189");}
if (temp==190){printf("190");}
if (temp==191){printf("191");}
if (temp==192){printf("192");}
if (temp==193){printf("193");}
if (temp==194){printf("194");}
if (temp==195){printf("195");}
if (temp==196){printf("196");}
if (temp==197){printf("197");}
if (temp==198){printf("198");}
if (temp==199){printf("199");}
if (temp==200){printf("200");}
if (temp==201){printf("201");}
if (temp==202){printf("202");}
if (temp==203){printf("203");}
if (temp==204){printf("204");}
if (temp==205){printf("205");}
if (temp==206){printf("206");}
if (temp==207){printf("207");}
if (temp==208){printf("208");}
if (temp==209){printf("209");}
if (temp==210){printf("210");}
if (temp==211){printf("211");}
if (temp==212){printf("212");}
if (temp==213){printf("213");}
if (temp==214){printf("214");}
if (temp==215){printf("215");}
if (temp==216){printf("216");}
if (temp==217){printf("217");}
if (temp==218){printf("218");}
if (temp==219){printf("219");}
if (temp==220){printf("220");}
if (temp==221){printf("221");}
if (temp==222){printf("222");}
if (temp==223){printf("223");}
if (temp==224){printf("224");}
if (temp==225){printf("225");}
if (temp==226){printf("226");}
if (temp==227){printf("227");}
if (temp==228){printf("228");}
if (temp==229){printf("229");}
if (temp==230){printf("230");}
if (temp==231){printf("231");}
if (temp==232){printf("232");}
if (temp==233){printf("233");}
if (temp==234){printf("234");}
if (temp==235){printf("235");}
if (temp==236){printf("236");}
if (temp==237){printf("237");}
if (temp==238){printf("238");}
if (temp==239){printf("239");}
if (temp==240){printf("240");}
if (temp==241){printf("241");}
if (temp==242){printf("242");}
if (temp==243){printf("243");}
if (temp==244){printf("244");}
if (temp==245){printf("245");}
if (temp==246){printf("246");}
if (temp==247){printf("247");}
if (temp==248){printf("248");}
if (temp==249){printf("249");}
if (temp==250){printf("250");}
if (temp==251){printf("251");}
if (temp==252){printf("252");}
if (temp==253){printf("253");}
if (temp==254){printf("254");}
if (temp==255){printf("255");}
		}

		return ret;

}

byte write_disk(drive_params t,word *ptr) /*reads a single sector and returns it */
{
	byte ret2;
	byte temp;
	word tmp2;
	dword tmp3;
		asm mov tmp3,cs
		asm mov es,tmp3
		asm mov bx,ptr
		asm mov ah,0x03
		asm mov al,1
		asm mov ch,t.cylinder
		asm mov cl,t.sector
		asm mov dh,t.head
		asm mov dl,t.drive
		asm mov ah,0x03
		asm int 0x13
asm mov temp,ah
		if (temp>0x00) {
		printf("woops");
		ret2=temp;
		if (temp==0){printf("0");}
if (temp==1){printf("1");}
if (temp==2){printf("2");}
if (temp==3){printf("3");}
if (temp==4){printf("4");}
if (temp==5){printf("5");}
if (temp==6){printf("6");}
if (temp==7){printf("7");}
if (temp==8){printf("8");}
if (temp==9){printf("9");}
if (temp==10){printf("10");}
if (temp==11){printf("11");}
if (temp==12){printf("12");}
if (temp==13){printf("13");}
if (temp==14){printf("14");}
if (temp==15){printf("15");}
if (temp==16){printf("16");}
if (temp==17){printf("17");}
if (temp==18){printf("18");}
if (temp==19){printf("19");}
if (temp==20){printf("20");}
if (temp==21){printf("21");}
if (temp==22){printf("22");}
if (temp==23){printf("23");}
if (temp==24){printf("24");}
if (temp==25){printf("25");}
if (temp==26){printf("26");}
if (temp==27){printf("27");}
if (temp==28){printf("28");}
if (temp==29){printf("29");}
if (temp==30){printf("30");}
if (temp==31){printf("31");}
if (temp==32){printf("32");}
if (temp==33){printf("33");}
if (temp==34){printf("34");}
if (temp==35){printf("35");}
if (temp==36){printf("36");}
if (temp==37){printf("37");}
if (temp==38){printf("38");}
if (temp==39){printf("39");}
if (temp==40){printf("40");}
if (temp==41){printf("41");}
if (temp==42){printf("42");}
if (temp==43){printf("43");}
if (temp==44){printf("44");}
if (temp==45){printf("45");}
if (temp==46){printf("46");}
if (temp==47){printf("47");}
if (temp==48){printf("48");}
if (temp==49){printf("49");}
if (temp==50){printf("50");}
if (temp==51){printf("51");}
if (temp==52){printf("52");}
if (temp==53){printf("53");}
if (temp==54){printf("54");}
if (temp==55){printf("55");}
if (temp==56){printf("56");}
if (temp==57){printf("57");}
if (temp==58){printf("58");}
if (temp==59){printf("59");}
if (temp==60){printf("60");}
if (temp==61){printf("61");}
if (temp==62){printf("62");}
if (temp==63){printf("63");}
if (temp==64){printf("64");}
if (temp==65){printf("65");}
if (temp==66){printf("66");}
if (temp==67){printf("67");}
if (temp==68){printf("68");}
if (temp==69){printf("69");}
if (temp==70){printf("70");}
if (temp==71){printf("71");}
if (temp==72){printf("72");}
if (temp==73){printf("73");}
if (temp==74){printf("74");}
if (temp==75){printf("75");}
if (temp==76){printf("76");}
if (temp==77){printf("77");}
if (temp==78){printf("78");}
if (temp==79){printf("79");}
if (temp==80){printf("80");}
if (temp==81){printf("81");}
if (temp==82){printf("82");}
if (temp==83){printf("83");}
if (temp==84){printf("84");}
if (temp==85){printf("85");}
if (temp==86){printf("86");}
if (temp==87){printf("87");}
if (temp==88){printf("88");}
if (temp==89){printf("89");}
if (temp==90){printf("90");}
if (temp==91){printf("91");}
if (temp==92){printf("92");}
if (temp==93){printf("93");}
if (temp==94){printf("94");}
if (temp==95){printf("95");}
if (temp==96){printf("96");}
if (temp==97){printf("97");}
if (temp==98){printf("98");}
if (temp==99){printf("99");}
if (temp==100){printf("100");}
if (temp==101){printf("101");}
if (temp==102){printf("102");}
if (temp==103){printf("103");}
if (temp==104){printf("104");}
if (temp==105){printf("105");}
if (temp==106){printf("106");}
if (temp==107){printf("107");}
if (temp==108){printf("108");}
if (temp==109){printf("109");}
if (temp==110){printf("110");}
if (temp==111){printf("111");}
if (temp==112){printf("112");}
if (temp==113){printf("113");}
if (temp==114){printf("114");}
if (temp==115){printf("115");}
if (temp==116){printf("116");}
if (temp==117){printf("117");}
if (temp==118){printf("118");}
if (temp==119){printf("119");}
if (temp==120){printf("120");}
if (temp==121){printf("121");}
if (temp==122){printf("122");}
if (temp==123){printf("123");}
if (temp==124){printf("124");}
if (temp==125){printf("125");}
if (temp==126){printf("126");}
if (temp==127){printf("127");}
if (temp==128){printf("128");}
if (temp==129){printf("129");}
if (temp==130){printf("130");}
if (temp==131){printf("131");}
if (temp==132){printf("132");}
if (temp==133){printf("133");}
if (temp==134){printf("134");}
if (temp==135){printf("135");}
if (temp==136){printf("136");}
if (temp==137){printf("137");}
if (temp==138){printf("138");}
if (temp==139){printf("139");}
if (temp==140){printf("140");}
if (temp==141){printf("141");}
if (temp==142){printf("142");}
if (temp==143){printf("143");}
if (temp==144){printf("144");}
if (temp==145){printf("145");}
if (temp==146){printf("146");}
if (temp==147){printf("147");}
if (temp==148){printf("148");}
if (temp==149){printf("149");}
if (temp==150){printf("150");}
if (temp==151){printf("151");}
if (temp==152){printf("152");}
if (temp==153){printf("153");}
if (temp==154){printf("154");}
if (temp==155){printf("155");}
if (temp==156){printf("156");}
if (temp==157){printf("157");}
if (temp==158){printf("158");}
if (temp==159){printf("159");}
if (temp==160){printf("160");}
if (temp==161){printf("161");}
if (temp==162){printf("162");}
if (temp==163){printf("163");}
if (temp==164){printf("164");}
if (temp==165){printf("165");}
if (temp==166){printf("166");}
if (temp==167){printf("167");}
if (temp==168){printf("168");}
if (temp==169){printf("169");}
if (temp==170){printf("170");}
if (temp==171){printf("171");}
if (temp==172){printf("172");}
if (temp==173){printf("173");}
if (temp==174){printf("174");}
if (temp==175){printf("175");}
if (temp==176){printf("176");}
if (temp==177){printf("177");}
if (temp==178){printf("178");}
if (temp==179){printf("179");}
if (temp==180){printf("180");}
if (temp==181){printf("181");}
if (temp==182){printf("182");}
if (temp==183){printf("183");}
if (temp==184){printf("184");}
if (temp==185){printf("185");}
if (temp==186){printf("186");}
if (temp==187){printf("187");}
if (temp==188){printf("188");}
if (temp==189){printf("189");}
if (temp==190){printf("190");}
if (temp==191){printf("191");}
if (temp==192){printf("192");}
if (temp==193){printf("193");}
if (temp==194){printf("194");}
if (temp==195){printf("195");}
if (temp==196){printf("196");}
if (temp==197){printf("197");}
if (temp==198){printf("198");}
if (temp==199){printf("199");}
if (temp==200){printf("200");}
if (temp==201){printf("201");}
if (temp==202){printf("202");}
if (temp==203){printf("203");}
if (temp==204){printf("204");}
if (temp==205){printf("205");}
if (temp==206){printf("206");}
if (temp==207){printf("207");}
if (temp==208){printf("208");}
if (temp==209){printf("209");}
if (temp==210){printf("210");}
if (temp==211){printf("211");}
if (temp==212){printf("212");}
if (temp==213){printf("213");}
if (temp==214){printf("214");}
if (temp==215){printf("215");}
if (temp==216){printf("216");}
if (temp==217){printf("217");}
if (temp==218){printf("218");}
if (temp==219){printf("219");}
if (temp==220){printf("220");}
if (temp==221){printf("221");}
if (temp==222){printf("222");}
if (temp==223){printf("223");}
if (temp==224){printf("224");}
if (temp==225){printf("225");}
if (temp==226){printf("226");}
if (temp==227){printf("227");}
if (temp==228){printf("228");}
if (temp==229){printf("229");}
if (temp==230){printf("230");}
if (temp==231){printf("231");}
if (temp==232){printf("232");}
if (temp==233){printf("233");}
if (temp==234){printf("234");}
if (temp==235){printf("235");}
if (temp==236){printf("236");}
if (temp==237){printf("237");}
if (temp==238){printf("238");}
if (temp==239){printf("239");}
if (temp==240){printf("240");}
if (temp==241){printf("241");}
if (temp==242){printf("242");}
if (temp==243){printf("243");}
if (temp==244){printf("244");}
if (temp==245){printf("245");}
if (temp==246){printf("246");}
if (temp==247){printf("247");}
if (temp==248){printf("248");}
if (temp==249){printf("249");}
if (temp==250){printf("250");}
if (temp==251){printf("251");}
if (temp==252){printf("252");}
if (temp==253){printf("253");}
if (temp==254){printf("254");}
if (temp==255){printf("255");}

		}

		
		return ret2;

}














	