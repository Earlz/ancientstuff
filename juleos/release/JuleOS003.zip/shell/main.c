/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Shell\Main.c; Contains the (unnamed)shell<<<<*/
/*>>>>Shell Extension Version 0.1.0<<<<*/
#ifndef SHELL
#define SHELL
#define SHELL_VERSION 0.0.1

#endif
void Shelp(void);
void Load_lowbasic(void);
void Scheck_scroll(void);
void testing(void);
signed int SMain(char* Arguments)  /*The big shell main; Arguments is currently not used and is there for future use; can return an error value*/
{
	char tmp[32];
	byte didit=0;
	unsigned char* command[scanf_BUFFER];
	tmp[0]=0;
	tmp[1]=0;
	init(tmp);
	tmp[0]=1;
	while (tmp[0]=1) {
		nl();
		printf("->:");
		*command=scanf();
		nl();
		if (streq(*command,"help")==1) { /*THANK YOU FOR THE PERSON WHO CREATED OPOS AND LET ME USE THE WONDERFUL FUNCTION OF streq*/
			Shelp(); didit=1;
		}
		if (streq(*command,"reboot")==1){ reboot(); didit=1;}
		if (streq(*command,"basic")==1){ Load_lowbasic(); didit=1;}
		if (streq(*command,"test")==1){testing(); didit=1;}
		

Scheck_scroll();

if (didit==0) {
	printf("Command not recognized!");
}

didit=0;
}
}

signed int init(char args[32]) /*shell initalization args is currently unused*/
{
	setvideomode(0x02);
	if (args[0]==1){
		setvideomode(0x02);}
		if (args[0]>1) { return -1;}
	setvideopage(args[1]);
	cls();
}

void Shelp(void) /*displays help message*/
{
			printf("basic -Starts the basic interpreter(not currently supported)");
			nl();
			printf("help -Displays this text");
			nl();
			printf("reboot -Reboots the PC");
			nl();
			printf("load -loads a sector from the currently floppy"); nl(); printf("disk to memory and  jumps to it");
}

void Load_lowbasic(void) /*probably wont be here for long*/
{
	printf("Currently under development."); nl(); printf("Remeber this is an alpha!");
}

void Scheck_scroll(void) /*checks the scrolling and if it is down to where u cant see the cursor it will cls*/
{
	if (getcury()>20) {
		printf("ok??");
		cls();
	}
}

void testing(void) /*just a reserved function for testing junk*/
{


	byte tmp2;
drive_params t;
	t.cylinder=0;
	t.head=0;
	t.sector=1;
	t.drive=0x00;
	reset_disks(0x00);
	*tmp5[0]='h';
	/*tmp2=write_disk(t,&*tmp5);*/
	*tmp5=read_disk(t);
printf(*tmp5);
if (*tmp5[0]==0xeb) { printf("yay!");}
/*try using get the address rather than return the var
/*asm mov WORD [es:20*4+2], CS omg that actually works*/
	/*U IDIOT u never did write hi to disk*/
}


void num2asci(word number)
{
}

/*

number to ascii numeric character converter

; ax = unsigned integer
; ax, at most, is a 5-digit number
mov si, outStr+4 ; point si at the right-most char of outStr
mov cx, 10 ; the base
xor dx, dx ; zero out dx as dx:ax will be divided by cx
LP:
div cx
; ax = Quotient ; dx = Remainder < cx(=10), so only dl matters
add dl, 30h ; convert a binary value to its ASCII numeric digit
mov [si], dl ; store this ASCII numeric digit to outStr
dec si ; point si to the next char (to the left)
xor dx, dx ; zero out dx (to prepare dx:ax for the next div)
or ax, ax ; check if ax is already zero
jnz LP ; if not, next loop; if yes, quit
inc si ; cancel out the effect of the last "dec si"
; so that si now points at the first (the left-most) char
; of the number to be printed
int 21h
...
outStr db '01234', 0 ; output string for a 5-digit numbe*/

		