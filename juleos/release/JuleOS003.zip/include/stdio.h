/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.1 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Include/stdio.h; Includes remakes of some of the most common C Library functions, Stable as of Tuesday, June 21, 2005 9:50 PM(GMT -6)<<<<*/

/*FORMATTED IS NOT YET ALLOWED*/
/*
void printf2(char* txt)
{
	if (txt[1]='e') {
		bprint('1');
	}
	if (*txt[1]='e' {
		bprint('0');
	}
	while (*txt!=0)
{
    bprint(*txt);

    ++txt;
}
}
*/
void printf(char* txt)  /*writes a string onto the screen, uses teletype, >need to add formatting support>*/
{
	byte tmp=0;
	while (txt[tmp]!=0) {
		bprint(txt[tmp]);
		++tmp;
	}
}

/*
char* scanf2() 
{ 
     char* txt[2048]; 
     char* tmp; 
     char* trash; 
     int a,b,c; 
     while (tmp!=10) { 
          a++ 
         *txt[a]=tmp; 
          getkey(&tmp,&trash); /*add delete function
          bprint(tmp);
          if(tmp == 13)
          {
               return txt;
          }
     }
}
*/
/*must put these functions into an interrupt somehow*/
void trapme(byte scan) /*key trapping mechanism for system calls*/
{
	if (scan==203) {
		putcur(getcurx()-1,getcurx());
	}
	if (scan==219) {
		printf("This isnt windows bitch!");
			getkey();
			reboot();
		}



}




unsigned char* scanf(void)  /*gets a string from the keyboard, breaks on enter, need to add arrow and backspace control*/
{ 
     unsigned char txt[scanf_BUFFER]; 
	keys returned;
     u8b* tmp; 
     unsigned char* trash; 
     int a,b=1,c; 
     a=0;
	while (b==1) {
		
		 returned=getkey(); /*get a char from the keyboard and store it in *tmp*/
		txt[a]=returned.asc; /*adds the just pressed key to txt*/
		 bprint(txt[a]); /*echos what you just pressed*/
		if (txt[a]==0) {
			a=a-1;
			putcur(getcurx()-1,getcury());
			trapme(returned.scan);
		}

		if (returned.scan==14) {
			if (a==0) {
			bprint(':');
				a=1;
		}
			bprint('');
			putcur(getcurx()-1,getcury());
			txt[a]=0;
			a=a-2;
		}
		 if (returned.scan==28) { /*if the user pressed enter then break*/
		 txt[a]=0; /*change to null*/
		 b=0;
		break;
		 }
		if (returned.scan==156) {
		txt[a]=0; /*change to null*/
		 b=0;
		}

		 a++; /*advance counter*/
		 }
	return txt;
}
		 
		
unsigned char* scanf_BACKUP(void)  /*gets a string from the keyboard, breaks on enter, need to add arrow and backspace control*/
{ 
     unsigned char txt[scanf_BUFFER]; 
     u8b* tmp; 
     unsigned char* trash; 
     int a,b=1,c; 
     a=0;
	while (b==1) {
		
		 *tmp=getkey1(); /*get a char from the keyboard and store it in *tmp*/
		txt[a]=*tmp; /*adds the just pressed key to txt*/
		 bprint(txt[a]); /*echos what you just pressed*/
		 if (txt[a]==13) { /*if the user pressed enter then break*/
		 txt[a]=0; /*change to null*/
		 b=0;
		break;
		 }
		 a++; /*advance counter*/
		 }
	return txt;
}
/*	
void scanf3(u8b pnt) 
{ 
     char* txt[2048]; 
     char* tmp; 
     char* trash; 
     int a,b=1,c; 
     while (b=1) 
     { 
          getkey(txt,&trash);
          txt[a]=*tmp; 
          bprint(*txt[a]); 
          if(txt[a] == 13) 
          { 
               break; 
          } 
          a++; 
     } 
     
}
*/
			