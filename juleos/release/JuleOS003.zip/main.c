/*>>>>JuleOS<<<<*/
/*>>>>Main Programmer: Jordan Earls<<<<*/
/*>>>>Version 0.0.3 ALPHA<<<<*/
/*>>>>16-Bit Edition<<<<*/
/*>>>>Just another toy OS>Inspired by OpenSourceOS(OPOS)*/
/*>>>>Built Using Turbo C with Turbo ASM<<<<*/
/*>>>>Main.c; Initializations, defines, includes, and calls the shell<<<<*/

#ifndef  _DEFS_H_
# define _DEFS_H_
# define JULEOS_VER 0.0.1
# define JULEOS_VERs "0.0.1"
# define scanf_BUFFER 128
 /* Color Constants */

 # define BLACK		0
 # define BLUE  	1
 # define GREEN		2
 # define CYAN		3
 # define RED		4
 # define MAGENTA	5
 # define BROWN 	6
 # define LIGHTGRAY	7
 # define DARKGRAY	8
 # define LIGHTBLUE 	9
 # define LIGHTGREEN	10
 # define LIGHTCYAN	11
 # define PINK		12
 # define LIGHTMAGENTA	13
 # define YELLOW	14
 # define WHITE		15

unsigned char DISPLAY_TYPE=1; /*1=vga 2=cga rest 3=text(maybe) */
 typedef signed	char	s8b	;
 typedef signed	int	s16b	;
 typedef signed long	s32b	;

 typedef unsigned char	u8b	;
 typedef unsigned int	u16b	;
 typedef unsigned long	u32b	;
 typedef unsigned char byte;
 typedef unsigned int word;
 typedef unsigned long dword;
typedef struct {
word cylinder;
word sector;
	byte head;
	byte drive;
	byte error;
}drive_params;
typedef struct{
	word cluster_size;
	dword disk_size; /*disk size in bytes for ease of development even if there is a 4gb limit*/
}fs_info;
typedef struct{
	byte scan;
	byte asc;
}keys;
byte video_page=0; /*This should be updated when video page is changed*/
word curx,cury;
byte *VideoMemory;
byte *tmp5[512];
# define NULL 	((void*)0)	
#endif
# include "lowlevel.c"
# include "midlevel.c"
# include "include\stdio.h"
# include "FDFS\FDFS.c"
# include "shell\main.c"

int main()
{

signed int ret;



	ret=SMain(0); /*call the shell main*/
/*add error checking for ret here*/

}


/*
Example on how to read a value from an address in a different offset(segment)
this reads how many coloums are on the screen
asm mov ax,0x0040
asm mov ah,0x0084
asm mov tmp,ax:ah
if (tmp==0x13) {
printf ("Yay!");
}
printf(tmp);
*/
	